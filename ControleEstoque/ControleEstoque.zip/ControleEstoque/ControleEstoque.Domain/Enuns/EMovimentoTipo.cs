﻿namespace ControleEstoque.Domain.Enuns
{
    public enum EMovimentoTipo
    {
        Entrada=0,
        Saida=1
    }
}
