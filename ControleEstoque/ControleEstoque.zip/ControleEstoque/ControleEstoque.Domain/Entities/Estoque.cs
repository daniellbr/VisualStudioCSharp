﻿using System.Collections.Generic;

namespace ControleEstoque.Domain.Entities
{
   public class Estoque :Entity
    {      

    }
}
